import subprocess
from unit_tests.test_playlist import run_tests

if __name__ == "__main__":
    run_tests()